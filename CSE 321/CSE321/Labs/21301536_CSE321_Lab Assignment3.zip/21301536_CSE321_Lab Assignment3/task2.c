#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

struct msg {
    long int type;
    char txt[6];
};

void mail(int msgid) {
    struct msg mssg;
    msgrcv(msgid, &mssg, sizeof(mssg.txt), 3, 0);
    printf("Mail received OTP from OTP generator: %s\n", mssg.txt);
    
    mssg.type = 4;
    msgsnd(msgid, &mssg, sizeof(mssg.txt), 0);
    printf("OTP sent to log in from mail: %s\n", mssg.txt);
}

void otp(int msgid) {
    struct msg mssg;
    pid_t otp = getpid();

    msgrcv(msgid, &mssg, sizeof(mssg.txt), 1, 0);
    printf("OTP generator received workspace name from log in: %s\n", mssg.txt);
    
    mssg.type = 2;
    snprintf(mssg.txt, 6, "%d", otp);
    msgsnd(msgid, &mssg, sizeof(mssg.txt), 0);
    printf("OTP sent to log in from OTP generator: %s\n", mssg.txt);

    if (fork() == 0) {
        mail(msgid);
        exit(0);
    } else {
        mssg.type = 3;
        snprintf(mssg.txt, 6, "%d", otp);
        msgsnd(msgid, &mssg, sizeof(mssg.txt), 0);
        printf("OTP sent to mail from OTP generator: %s\n", mssg.txt);

        wait(NULL);
        exit(0);
    }
}

void login(int msgid) {
    struct msg mssg;
    char input[6];
    
    printf("Please enter the workspace name:\n");
    scanf("%s", input);
    
    if (strcmp(input, "cse321") != 0) {
        printf("Invalid workspace name\n");
        exit(0);
    }
    
    mssg.type = 1;
    strncpy(mssg.txt, input, 6);
    msgsnd(msgid, &mssg, sizeof(mssg.txt), 0);
    printf("Workspace name sent to otp generator from log in: %s\n", input);

    wait(NULL);
    wait(NULL);

    msgrcv(msgid, &mssg, sizeof(mssg.txt), 2, 0);
    printf("Log in received OTP from OTP generator: %s\n", mssg.txt);

    msgrcv(msgid, &mssg, sizeof(mssg.txt), 4, 0);
    printf("Log in received OTP from mail: %s\n", mssg.txt);

    if (mssg.type == 4) {
        printf("OTP Verified\n");
    } else {
        printf("OTP Incorrect\n");
    }

    msgctl(msgid, IPC_RMID, NULL);
}

int main() {
    int msgid = msgget(1234, IPC_CREAT | 0666);
    if (msgid < 0) {
        perror("msgget");
        exit(1);
    }

    if (fork() == 0) {
        otp(msgid);
    } else {
        login(msgid);
    }

    return 0;
}