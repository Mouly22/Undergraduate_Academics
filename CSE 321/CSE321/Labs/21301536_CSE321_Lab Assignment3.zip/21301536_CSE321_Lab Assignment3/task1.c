#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>
#include <errno.h>

struct shared {
    char sel[100];
    int b;
};

int main() {
    key_t key = 1234;
    int shm_id = shmget(key, sizeof(struct shared), IPC_CREAT | 0666);
    if (shm_id == -1) {
        perror("shmget");
        exit(1);
    }

    struct shared *shm_ptr = (struct shared *)shmat(shm_id, NULL, 0);
    if (shm_ptr == (void *)-1) {
        perror("shmat");
        exit(1);
    }

    int pipe_fd[2];
    if (pipe(pipe_fd) == -1) {
        perror("pipe");
        exit(1);
    }

    pid_t pid = fork();
    if (pid == -1) {
        perror("fork");
        exit(1);
    }

    if (pid == 0) {
        close(pipe_fd[0]);

        struct shared *shared_data = shm_ptr;
        
        while (1) {
            if (strlen(shared_data->sel) > 0) {
                if (strcmp(shared_data->sel, "a") == 0) {
                    int balance;
                    printf("Enter balance to be added:\n");
                    scanf("%d", &balance);

                    if (balance > 0) {
                        shared_data->b += balance;
                        printf("Balance added successfully\n");
                        printf("Updated balance after addition:\n%d\n", shared_data->b);
                    } else {
                        printf("Adding failed, Invalid balance\n");
                    }
                } else if (strcmp(shared_data->sel, "w") == 0) {
                    int balance;
                    printf("Enter balance to be withdrawn:\n");
                    scanf("%d", &balance);

                    if (balance > 0 && balance <= shared_data->b) {
                        shared_data->b -= balance;
                        printf("Balance withdrawn successfully\n");
                        printf("Updated balance after withdrawal:\n%d\n", shared_data->b);
                    } else {
                        printf("Withdrawal failed, Invalid balance\n");
                    }
                } else if (strcmp(shared_data->sel, "c") == 0) {
                    printf("Your current balance is:\n%d\n", shared_data->b);
                } else {
                    printf("Invalid selection\n");
                }

                shared_data->sel[0] = '\0';
                write(pipe_fd[1], "Thank you for using", 20);
                break;
            }
        }

        close(pipe_fd[1]);
        exit(0);
    } else {
        close(pipe_fd[1]);

        char select;
        printf("Provide Your Input From Given Options:\n");
        printf("1. Type a to Add Money\n");
        printf("2. Type w to Withdraw Money\n");
        printf("3. Type c to Check Balance\n");

        scanf(" %c", &select);
        shm_ptr->sel[0] = select;
        shm_ptr->b = 1000;

        printf("Your selection: %c\n", select);

        wait(NULL);

        char buffer[1000];
        ssize_t len = read(pipe_fd[0], buffer, sizeof(buffer) - 1);
        if (len > 0) {
            buffer[len] = '\0';
            printf("%s\n", buffer);
        }

        close(pipe_fd[0]);
        shmdt(shm_ptr);
        shmctl(shm_id, IPC_RMID, NULL);

        return 0;
    }
}
