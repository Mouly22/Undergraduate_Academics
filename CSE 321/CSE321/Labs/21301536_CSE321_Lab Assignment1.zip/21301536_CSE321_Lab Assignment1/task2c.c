#include <stdio.h>

void passwordChecker(char password[]){
	int uflag = 0;
	int lflag = 0;
	int dflag = 0;
	int sflag = 0;
	
	char special[] = "@#$%&-_";
	for(int i = 0; password[i] != '\0'; i++){
		if(password[i] >= 'A' && password[i] <= 'Z'){
			uflag = 1;
		}
		else if(password[i] >= 'a' && password[i] <= 'z'){
			lflag = 1;
		}
		else if(password[i] >= '0' && password[i] <= '9'){
			dflag = 1;
		}
		else{
			for(int j = 0; special[j] != '\0'; j++){
				if(password[i] == special[j]){
					sflag = 1;
					break;
				}
			}
		}
	}
	
	int flags = 4 - (uflag + lflag + dflag + sflag); 
	if(!flags){
		printf("Valid Pattern: OK\n");
	}
	else{
		printf("Invalid Pattern: ");
		if(!uflag){
			printf("Uppercase Character Missing");
			flags--;
			if(flags > 0){
				printf(", ");
			}
			else{
				printf("\n");
			}
		}
		if(!lflag){
			printf("Lowercase Character Missing");
			flags--;
			if(flags > 0){
				printf(", ");
			}
			else{
				printf("\n");
			}
		}
		if(!dflag){
			printf("Digit Missing");
			flags--;
			if(flags > 0){
				printf(", ");
			}
			else{
				printf("\n");
			}
		}
		if(!sflag){
			printf("Special Character Missing");
			flags--;
			if(flags > 0){
				printf(", ");
			}
			else{
				printf("\n");
			}
		}
	}
}

void main(){
	char password[1000];
	printf("Enter your Password: ");
	scanf("%s", password);
	passwordChecker(password);
}
