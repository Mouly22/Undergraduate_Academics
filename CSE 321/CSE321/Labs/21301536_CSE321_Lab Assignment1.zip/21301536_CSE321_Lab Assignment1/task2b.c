#include <stdio.h>

void spaceRemover(char input[], char output[]) {
    int i = 0;
    int j = 0;
    int space = 0;

    for (; input[i] != '\0'; i++) {
        if (input[i] == ' ') {
            if (!space) {
                output[j++] = input[i];
                space = 1;
            }
        } else {
            output[j++] = input[i];
            space = 0;
        }
    }
    output[j] = '\0';
}

void main() {
    FILE *infile = fopen("input2b.txt", "r");
    FILE *outfile = fopen("output2b.txt", "w");

    if (infile && outfile) {
        char given[1000];
        fgets(given, sizeof(given), infile);
        printf("Given String: %s\n", given);

        char result[1000];
        spaceRemover(given, result);
        fprintf(outfile, "%s", result);
        printf("After Spaces Removed: %s\n", result); 

        fclose(infile);
        fclose(outfile);
    } else {
        printf("Error opening files.\n");
    }
}



