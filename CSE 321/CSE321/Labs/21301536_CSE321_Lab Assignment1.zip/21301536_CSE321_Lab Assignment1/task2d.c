#include <stdio.h>

void domainChecker(char email[]){
	int i = 0;
	while(email[i] != '@'){
		i++;
	}
	
	int j = 0;
	int flag = 0;
	char domain[] = "@sheba.xyz";
	for(; email[i] != '\0'; i++){
		if(email[i] != domain[j]){
			flag = 1;
			break;
		}
		else{
			j++;
		}
	}
	
	if(flag){
		printf("Email Address is outdated\n");
	}
	else{
		printf("Email Address is okay\n");
	}
}

void main(){
	char email[1000];
	printf("Enter your Email: ");
	scanf("%s", email);
	domainChecker(email);
}


