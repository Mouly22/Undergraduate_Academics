#include <stdio.h>

void palindromeChecker(char string[]){
	char *start = string;
	char *end = string;
	while(*end != '\0'){
		end++;
	}
	end--;
	
	int flag = 0;
	while(start < end){
		if(*start != *end){
			flag = 1;
			break;
		}
		start++;
		end--;
	}
	
	if(flag){
		printf("Result: Not Palindrome\n");
	}
	else{
		printf("Result: Palindrome\n");
	}
}

void main(){
	char string[1000];
	printf("Enter String: ");
	scanf("%s", string);
	palindromeChecker(string);
}


