#include <stdio.h>

void main(){
	int num1;
	printf("Enter 1st Number: ");
	scanf("%d", &num1);
	
	int num2;
	printf("Enter 2nd Number: ");
	scanf("%d", &num2);
	
	if (num1 > num2){
		printf("Result: %d\n", num1 - num2);
	}
	else if (num1 < num2){
		printf("Result: %d\n", num1 + num2);
	}
	else {
		printf("Result: %d\n", num1 * num2);
	}
}
