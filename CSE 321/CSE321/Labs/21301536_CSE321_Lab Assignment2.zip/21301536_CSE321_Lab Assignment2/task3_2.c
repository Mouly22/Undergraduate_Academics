#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

void* printInt(void* arg) {
    int tid = *(int*)arg;
    int start = tid * 5 + 1;
    
    for (int i = 0; i < 5; ++i) {
        printf("Thread %d prints %d\n", tid, start + i);
    }
    
    pthread_exit(NULL);
}

int main() {
    const int NUM_THREADS = 5;
    pthread_t threads[NUM_THREADS];
    int tids[NUM_THREADS];
    
    for (int i = 0; i < NUM_THREADS; ++i) {
        tids[i] = i;
        if (pthread_create(&threads[i], NULL, printInt, (void*)&tids[i]) != 0) {
            perror("Failed to create thread");
            exit(1);
        }
    }
    
    for (int i = 0; i < NUM_THREADS; ++i) {
        if (pthread_join(threads[i], NULL) != 0) {
            perror("Failed to join thread");
            exit(1);
        }
    }
    
    return 0;
}
