#include <stdio.h>
#include <stdlib.h>

void oddEven(int arr[], int size) {
    for (int i = 0; i < size; ++i) {
        if (arr[i] % 2 == 0) {
            printf("%d is even\n", arr[i]);
        } else {
            printf("%d is odd\n", arr[i]);
        }
    }
}

int main(int argc, char *argv[]) {
    int size = argc - 1;
    int *numbers = (int *)malloc(size * sizeof(int));
    for (int i = 0; i < size; ++i) {
        numbers[i] = atoi(argv[i + 1]);
    }

    oddEven(numbers, size);
    return 0;
}
