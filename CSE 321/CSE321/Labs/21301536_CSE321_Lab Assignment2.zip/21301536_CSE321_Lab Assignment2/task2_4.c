#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

void sortDesc(int arr[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = i + 1; j < size; ++j) {
            if (arr[i] < arr[j]) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

void oddEven(int arr[], int size) {
    for (int i = 0; i < size; ++i) {
        if (arr[i] % 2 == 0) {
            printf("%d is even\n", arr[i]);
        } else {
            printf("%d is odd\n", arr[i]);
        }
    }
}

int main(int argc, char *argv[]) {
    int size = argc - 1;
    int *numbers = (int *)malloc(size * sizeof(int));
    for (int i = 0; i < size; ++i) {
        numbers[i] = atoi(argv[i + 1]);
    }

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        return 1;
    }

    if (pid == 0) {
        sortDesc(numbers, size);
        printf("Sorted Array: ");
        for (int i = 0; i < size; ++i) {
            printf("%d ", numbers[i]);
        }
        printf("\n");
        exit(0);
    } else {
        wait(NULL);
        printf("\nOdd/Even Status:\n");
        oddEven(numbers, size);
    }
    return 0;
}
