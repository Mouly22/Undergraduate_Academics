#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#define NUM_THREADS 5

void* tfunc(void* arg) {
    int tnum = *((int*)arg);
    printf("thread-%d running\n", tnum);
    sleep(1);
    printf("thread-%d closed\n", tnum);
    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];
    int targs[NUM_THREADS];
    int rc;

    for (int i = 0; i < NUM_THREADS; i++) {
        targs[i] = i + 1;
        rc = pthread_create(&threads[i], NULL, tfunc, (void*)&targs[i]);
        if (rc) {
            fprintf(stderr, "Error: unable to create thread %d, %d\n", i, rc);
            exit(-1);
        }
        pthread_join(threads[i], NULL);
    }

    return 0;
}
