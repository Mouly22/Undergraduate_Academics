#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t child_pid, gchild_pid, gchild_pid1, gchild_pid2, gchild_pid3;

    printf("Parent process ID : %d\n", getpid());

    child_pid = fork();
    if (child_pid < 0) {
        perror("fork failed");
        exit(1);
    } else if (child_pid == 0) {
        printf("Child process ID: %d\n", getpid());

        for (int i = 0; i < 3; i++) {
            gchild_pid = fork();
            
            if (gchild_pid < 0) {
                perror("fork failed");
                exit(1);
            } else if (gchild_pid == 0) {
                printf("Grand Child process ID: %d\n", getpid());
                exit(0);
            }
        }
        for (int i = 0; i < 3; i++) {
            wait(NULL);
        }
    } else {
        wait(NULL);
    }

    return 0;
}
