#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

struct ThreadArgs {
    char *name;
    int num;
};

void* calcAscii(void *args) {
	int sum = 0;
    struct ThreadArgs *targs = (struct ThreadArgs *)args;
    for (int i = 0; i < strlen(targs->name); i++) {
        sum += targs->name[i];
    }
    targs->num = sum;
    pthread_exit(NULL);
}

void* compare(void *args) {
    int *res = (int *)args;
    if (res[0] == res[1] && res[1] == res[2]) {
        printf("Youreka\n");
    } else if (res[0] == res[1] || res[1] == res[2] || res[0] == res[2]) {
        printf("Miracle\n");
    } else {
        printf("Hasta la vista\n");
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t threads[4];
    struct ThreadArgs targs[3];
    int res[3];

    targs[0].name = "Farhan";
    targs[1].name = "Haseen";
    targs[2].name = "Prantor";

    for (int i = 0; i < 3; i++) {
        pthread_create(&threads[i], NULL, calcAscii, (void *)&targs[i]);
    }

    for (int i = 0; i < 3; i++) {
        pthread_join(threads[i], NULL);
        res[i] = targs[i].num;
    }

    pthread_create(&threads[3], NULL, compare, (void *)res);
    pthread_join(threads[3], NULL);

    return 0;
}
