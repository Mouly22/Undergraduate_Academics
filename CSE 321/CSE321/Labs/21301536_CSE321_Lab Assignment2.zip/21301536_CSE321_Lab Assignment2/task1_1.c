#include <stdio.h>

struct Paratha{
	int qty;
	int cost;
};

struct Vegetables{
	int qty;
	int cost;
};

struct Water{
	int qty;
	int cost;
};

int main() {
	struct Paratha p;
	struct Vegetables v;
	struct Water w;
	
	int total;
	int people;
	float bill;
	
	printf("Quantity of Paratha: ");
	scanf("%d", &p.qty);

	printf("Unit Price: ");
	scanf("%d", &p.cost);
	
	printf("Quantity of Vegetables: ");
	scanf("%d", &v.qty);

	printf("Unit Price: ");
	scanf("%d", &v.cost);
	
	printf("Quantity of Mineral Water: ");
	scanf("%d", &w.qty);

	printf("Unit Price: ");
	scanf("%d", &w.cost);
	
	printf("Number of People: ");
	scanf("%d", &people);
	
	total = p.qty * p.cost + v.qty * v.cost + w.qty * w.cost;
	bill = total/people;

	printf("Individual people will pay: %.2f tk\n", bill);
}







