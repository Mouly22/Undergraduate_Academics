#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    int fd;
    char buffer[1000];
    ssize_t rsize, wsize;

    fd = open(argv[1], O_WRONLY | O_CREAT, 0666);
    if (fd == -1) {
        perror("Error opening or creating the file");
        exit(1);
    }

    while (1) {
        rsize = read(0, buffer, sizeof(buffer) - 1);
        buffer[strcspn(buffer, "\n")] = 0;

        if (strcmp(buffer, "-1") == 0) {
            break;
        }

        wsize = write(fd, buffer, strlen(buffer));
        wsize = write(fd, "\n", 1);
    }
	close(fd);
    return 0;
}
