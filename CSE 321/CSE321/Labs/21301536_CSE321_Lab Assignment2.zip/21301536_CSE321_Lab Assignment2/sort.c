#include <stdio.h>
#include <stdlib.h>

void sortDesc(int arr[], int size) {
    for (int i = 0; i < size - 1; ++i) {
        for (int j = i + 1; j < size; ++j) {
            if (arr[i] < arr[j]) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

int main(int argc, char *argv[]) {
	int size = argc - 1;
    int *numbers = (int *)malloc(size * sizeof(int));
	for (int i = 0; i < size; ++i) {
        numbers[i] = atoi(argv[i + 1]);
    }

    sortDesc(numbers, size);
    printf("Sorted Array: ");
    for (int i = 0; i < size; ++i) {
        printf("%d ", numbers[i]);
    }
    printf("\n");
    return 0;
}
