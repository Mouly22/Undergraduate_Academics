#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int count = 1;

void oddCheck(pid_t pid) {
    if (pid % 2 != 0) {
        pid_t new = fork();
        if (new == 0) {
            exit(0);
        } else if (new > 0) {
            count++;
        }
    }
}

int main() {
    pid_t a, b, c;

    a = fork();
    if (a == 0) {
        exit(0);
    } else if (a > 0) {
        count++;
        oddCheck(a);
    }

    b = fork();
    if (b == 0) {
        exit(0);
    } else if (b > 0) {
        count++;
        oddCheck(b);
    }

    c = fork();
    if (c == 0) {
        exit(0);
    } else if (c > 0) {
        count++;
        oddCheck(c);
    }

    while (wait(NULL) > 0);

    printf("Total Processes: %d\n", count);

    return 0;
}
