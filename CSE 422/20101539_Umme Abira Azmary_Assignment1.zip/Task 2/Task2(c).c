#include <stdio.h>
#include<string.h>

int main() {
  puts("Enter your password: ");
  char pass[100];
  scanf("%s", pass);
  int count = 0;
  int up = 0; 
  int low = 0;
  int nums = 0;
  int special = 0;

  while (pass[count] != '\0') {

   char vals = pass[count];
   if (vals >= 'A' && vals <= 'Z'){
    up = 1;
   }
   else if (vals >= 'a' && vals <= 'z') {
      low = 1;
    }
  else if (vals >= '0' && vals <= '9') {
    nums = 1;
  }
  else if ((vals == '_') || (vals == '$') || (vals == '@') || (vals == '#')){
    special = 1;
  }
    count++;
  }
        
int flag1 = 0;
  if (!up) {
      if (flag1 == 1){
          printf(", ");
      }
        printf("Uppercase character missing");
        flag1 = 1;
        
    }
  if (!low){
            if (flag1 == 1){
          printf(", ");
      }
    printf("Lowercase character missing");
    flag1 = 1;
  }
  if (!nums) {
            if (flag1 == 1){
          printf(", ");
      }
      printf("Digit missing");
  }
  if (!special) {
            if (flag1 == 1){
          printf(", ");
      }
      printf("Special character missing");
      flag1 = 1;
    }

   
  if (up && low && nums && special) {
        printf("OK");
        flag1 = 1;
    }

    return 0;
}