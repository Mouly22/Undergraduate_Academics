#include <stdio.h>
#include <string.h>


int main() {

  int val1, val2;
  puts("Enter input numbers:");
  scanf("%d %d", &val1, &val2);

  if (val1 > val2){
  val1 = val1 - val2;
  }
  else if (val1 < val2){
    val1 = val1 + val2;
  }
  else{
    val1 = val1*val2;
  }
  printf("The result is : %d", val1);


  return 0;
}