#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() {
  char inp[300];
  puts("Enter an input: ");
  scanf("%s", inp);
  int no_val = 0;

  const char *p1 = inp;
  const char *p2 = inp + strlen(inp) - 1;

  while (p1 < p2) {
        if ((*p1) != (*p2)) {
          no_val = 1;
        }
       
        p1++;
        p2--;
  }

  if (no_val== 1){
    printf("Not Palindrome\n");}

  else{
    printf("Palindrome\n");
  }

  return 0;

}