#include <stdio.h>
#include <string.h>

int main() {
    puts("Enter your email address: ");
    char email[300];
    scanf("%s", email);
    
    char doms[300];
    const char domain1[] = "kaaj.com"; 
    const char domain2[] = "sheba.xyz";
    int count = 0;
    int store = 0;
    int vals = 0;

    while (email[count] != '\0') {
        char current = email[count];
        if (current == '@') {
            store = 1;
        }

        if (store == 1) {
            doms[vals] = email[count + 1];
            vals++;
        }

        count++;
    }
    doms[vals] = '\0';

    if (strcmp(doms, domain1) == 0) {
        printf("Email address is outdated\n");
    } else if (strcmp(doms, domain2) == 0) {
        printf("Email address is okay\n");
    }
    else{
      printf("Enter email address again!");
    }

    return 0;
}