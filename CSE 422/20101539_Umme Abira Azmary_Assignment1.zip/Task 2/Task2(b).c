#include <stdio.h>
#include <string.h>

int main() {

    FILE *inp;
    char inp_array[100];
    char n_array[100] = " ";
    inp = fopen("temptext.txt", "r");
    while (fscanf(inp, "%s", inp_array) != EOF){
        strcat(n_array, inp_array);
        strcat(n_array, " ");

    }

    fclose(inp);
for (int i = 1; i < 100; i++) {
    n_array[i-1] = n_array[i];
}
    printf("%s\n", n_array);

    return 0;
}